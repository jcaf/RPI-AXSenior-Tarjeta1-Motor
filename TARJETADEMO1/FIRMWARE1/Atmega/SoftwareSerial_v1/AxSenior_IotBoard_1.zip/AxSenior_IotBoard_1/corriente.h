#ifndef CORRIENTE_H_
#define CORRIENTE_H_
void Irms_get(void);
extern float irms;
#endif // CORRIENTE_H_
