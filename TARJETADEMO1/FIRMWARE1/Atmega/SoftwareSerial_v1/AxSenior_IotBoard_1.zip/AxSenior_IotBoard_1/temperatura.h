#ifndef TEMPERATURA_T_
#define TEMPERATURA_T_

    extern float temperature;
    void temp_process(void);
#endif // TEMPERATURA_T_
