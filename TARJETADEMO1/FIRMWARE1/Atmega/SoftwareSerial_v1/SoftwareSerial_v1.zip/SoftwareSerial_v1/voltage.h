#ifndef VOLTAGE_H_
#define VOLTAGE_H_

    extern float volt;
    void voltage_init(void);
    //float get_voltage(void);
    void process_voltage(void);

#endif // VOLTAGE_H_
